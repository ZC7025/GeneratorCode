package com.zc.used.query;

import java.io.Serializable;

/**
 * 所有查询对象的父类<br />
 * 创建于2017-11-25
 *
 * @author 王振宇
 * @version 1.0
 */
public class BaseQuery implements Serializable {
    private static final long serialVersionUID = -103627828371415217L;
}
